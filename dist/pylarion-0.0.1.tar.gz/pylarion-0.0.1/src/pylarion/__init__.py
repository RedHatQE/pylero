# -*- coding: utf8 -*-
from __future__ import absolute_import, division, print_function
from __future__ import unicode_literals

"""Pylarion is a Python wrapper for the Polarion WSDL API. It implements the
API in a native Python object oriented approach, using objects to wrap like
functionality.
"""
